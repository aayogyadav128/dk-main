const panditData = [
    {
      id: 1,
      name: "Mohan Singh",
      description: "Hi, I have 2 years of experience in the data field.",
      image: "https://nextui.org/images/hero-card-complete.jpeg",
      chargePerHour: 12
    },
    {
      id: 2,
      name: "Rajesh",
      description: "Expert in Vedic rituals with 5 years of experience.",
      image: "https://nextui.org/images/hero-card-complete.jpeg",
      chargePerHour: 15
    },
    {
      id: 3,
      name: "Anita",
      description: "Specialized in astrology and spiritual healing.",
      image: "https://nextui.org/images/hero-card-complete.jpeg",
      chargePerHour: 10
    },
    {
      id: 4,
      name: "Suresh",
      description: "Over 8 years of experience in conducting various poojas.",
      image: "https://nextui.org/images/hero-card-complete.jpeg",
      chargePerHour: 20
    },
    {
      id: 5,
      name: "Priya",
      description: "A modern pandit with a blend of traditional and contemporary practices.",
      image: "https://nextui.org/images/hero-card-complete.jpeg",
      chargePerHour: 18
    }
  ];
  
  export default panditData