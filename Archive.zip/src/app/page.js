
import PoojaList from "@/components/ListPagination";
import PoojaCard from "@/components/PoojaCard";
import Image from "next/image";
import ProductPage from "@/components/ProductPage";
import AddReview from "@/components/AddReview";
import ImageSlider from "@/components/homeScreen/ImageSlider";
import { image } from "@nextui-org/react";
import BookingOptionsCard from "@/components/homeScreen/BookingSelector";
import PoojaCardGrid from "@/components/homeScreen/HomeProductHolder";
import OffersSection from "@/components/homeScreen/OffersSection";
import PanditCard from "@/components/PanditCard";
import SecondaryNavbar from "@/components/StayNavbar";
import MainSecondaryNavbar from "@/components/MainSecondaryNavbar";
import Loading from "@/components/loading";



export default async function Home() {
  const res = await fetch('https://admin.divyakumbh.in/api/poojas?populate[pooja_reviews][populate]=users_permissions_user&populate=photos');
  const data = await res.json();
  const products = data.data;

  return (
    <div>
      {products.map((product, index) => (
        <ProductPage
          key={index}
          title={product?.attributes?.title_english}
          price={product?.attributes?.plans}
          description={product?.attributes?.description_english}
          images={product?.attributes?.photos?.data.map(item => 'https://admin.divyakumbh.in'+item.attributes.url)||[]}
          reviews={product?.attributes?.pooja_reviews?.data.map(item => {
            return {
            reviewer:item.attributes.users_permissions_user.data.attributes.username,
            comment:item.attributes.message,
            rating:item.attributes.rating
          }})||[]}
          variations={['Morning', 'Evening']}
          id={product.id}
        />
      ))}
    </div>
  );
}
