// app/components/ProtectedPage.js
"use client"; // Mark as a client component

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { parseCookies} from 'nookies'; // To store JWT in cookies


function ProtectedPage({ children }) {
  const { user } = useAuth();
  const router = useRouter();

  useEffect(() => {
    // Check if JWT is already present in cookies
    const cookies = parseCookies();
    const jwt = cookies.jwt;

    // If JWT exists, redirect to dashboard
    if (!jwt) {
        router.push('/login');
    }
}, [router]);

  return user ? children : null;
}

export default ProtectedPage;
