'use client';

import { setCookie ,parseCookies} from 'nookies'; // To store JWT in cookies
import { useRouter } from 'next/navigation';
import React, { useState,useEffect } from 'react';
import { Button, Input } from '@nextui-org/react'; // Ensure correct import path for Next UI

const Login = () => {
    const router = useRouter();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(''); // State to handle error messages
    useEffect(() => {
        // Check if JWT is already present in cookies
        const cookies = parseCookies();
        const jwt = cookies.jwt;

        // If JWT exists, redirect to dashboard
        if (jwt) {
            router.push('/');
        }
    }, [router]);

    const handleSignIn = async () => {
        setError(''); // Clear previous error before new request

        try {
            const response = await fetch('https://admin.divyakumbh.in/api/auth/local', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': '*/*',
                },
                body: JSON.stringify({
                    identifier: email, // The API expects 'identifier'
                    password: password, // The API expects 'password'
                }),
            });
            console.log(response)
            const result = await response.json();

            if (response.ok) {
                // If login is successful, store the JWT in cookies
                setCookie(null, 'jwt', result.jwt, {
                    maxAge: 30 * 24 * 60 * 60, // JWT expires in 30 days
                    path: '/',
                });
                setCookie(null, 'user_id', result.user.id, {
                    maxAge: 30 * 24 * 60 * 60, // user_id expires in 30 days
                    path: '/',
                });
                setCookie(null, 'user_username', result.user.username, {
                    maxAge: 30 * 24 * 60 * 60, // user_username expires in 30 days
                    path: '/',
                });
                setCookie(null, 'user_email', result.user.email, {
                    maxAge: 30 * 24 * 60 * 60, // user_email expires in 30 days
                    path: '/',
                });

                // Redirect to dashboard
                router.push('/');
            } else {
                // If the API returns an error
                setError(result?.error?.message || 'An error occurred during login.');
            }
        } catch (err) {
            console.error('Error during login:', err);
            setError('An error occurred during login.');
        }
    };

    return (
        <div>
            <h1>Login</h1>
            {error && <p style={{ color: 'red' }}>{error}</p>} {/* Display error message */}
            <Input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
            />
            <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
            />
            <Button onClick={handleSignIn}>Sign In</Button>
        </div>
    );
};

export default Login;
