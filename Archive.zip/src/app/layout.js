import { Inter } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Provider from "./provider";
import Footer2 from "@/components/Footer";
import { Card, Divider } from "@nextui-org/react";
import SecondaryNavbar from "@/components/StayNavbar";
import { AuthProvider } from "@/context/AuthContext";


const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "Divya Kumbh",
  description: "Experience the easyness of Spirituality",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">

      <body className={inter.className}>
        <Provider>
        <Header />
        <Card radius="none"><AuthProvider>{children}</AuthProvider><Divider /></Card><Footer2 /></Provider></body>
    </html>
  );
}
