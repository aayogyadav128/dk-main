import SecondaryNavbar from '@/components/StayNavbar'
import React from 'react'

const layout = ({children}) => {
  return (
    <div>
        <SecondaryNavbar />
      {children}
    </div>
  )
}

export default layout
