'use client';
import { useEffect, useState } from 'react';
import { getPrivacy } from '../../../firebaseUtils';

const PrivacyPolicy = ({ params }) => {
    const [privacyContent, setPrivacyContent] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const lang = params.lan || 'en'; // Default to 'en' if no language is provided

    useEffect(() => {
        const fetchPrivacyPolicy = async () => {
            try {
                const content = await getPrivacy(lang);
                setPrivacyContent(content);
            } catch (err) {
                setError('Failed to load privacy policy.');
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        fetchPrivacyPolicy();
    }, [lang]);

    if (loading) {
        return <p>Loading...</p>;
    }

    if (error) {
        return <p>{error}</p>;
    }

    return (
        <div>
            <div dangerouslySetInnerHTML={{ __html: privacyContent }} />
        </div>
    );
};

export default PrivacyPolicy;