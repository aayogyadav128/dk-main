'use client'
import { useEffect, useState } from 'react';
import { getShippingPolicy } from '../../firebaseUtils';

const ShippingPolicy = () => {
    const [shippingContent, setShippingContent] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchShippingPolicy = async () => {
            try {
                const content = await getShippingPolicy();
                setShippingContent(content);
            } catch (err) {
                setError('Failed to load shipping policy.');
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        fetchShippingPolicy();
    }, []);

    if (loading) {
        return <p>Loading...</p>;
    }

    if (error) {
        return <p>{error}</p>;
    }

    return (
        <div>
            <h1>Shipping Policy</h1>
            <div dangerouslySetInnerHTML={{ __html: shippingContent }} />
        </div>
    );
};

export default ShippingPolicy;
