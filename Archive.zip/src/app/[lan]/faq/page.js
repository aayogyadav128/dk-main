import React from 'react';
import { Accordion,AccordionItem } from '@nextui-org/react';

const FAQPage = () => {
    const faqs = [
        { question: 'What is the purpose of this website?', answer: 'The purpose of this website is to...' },
        { question: 'How do I create an account?', answer: 'To create an account, you need to...' },
        { question: 'How can I contact customer support?', answer: 'You can contact our customer support team by...' },
    ];

    return (
        <div>
            <h1>Frequently Asked Questions</h1>
            <Accordion>
                {faqs.map((faq, index) => (
                    <AccordionItem key={index} title={faq.question}>
                        <p>{faq.answer}</p>
                    </AccordionItem>
                ))}
            </Accordion>
        </div>
    );
};

export default FAQPage;