import PoojaList from '@/components/ListPagination'
import React from 'react'

const page = () => {
  return (
    <div>
       <h1 className="text-center font-bold text-lg py-4">All Poojas</h1>
      <PoojaList />
    </div>
  )
}

export default page
