"use client";

import React, { useState, useEffect } from "react";
import { Button, Card, CardHeader, CardBody, CardFooter } from "@nextui-org/react";
import ProtectedPage from "@/app/ProtectedPage";

const CartPreview = () => {
  const [cart, setCart] = useState([]);

  // Load cart from localStorage when the component mounts
  useEffect(() => {
    const savedCart = JSON.parse(localStorage.getItem("cart")) || [];
    console.log("Cart length : ",savedCart.length)
    setCart(savedCart);
  }, []);

  // Remove item from the cart
  const handleRemoveItem = (itemName) => {
    const updatedCart = cart.filter(item => item.Name !== itemName);
    setCart(updatedCart);
    localStorage.setItem("cart", JSON.stringify(updatedCart));
  };

  // Empty the cart
  const handleEmptyCart = () => {
    setCart([]);
    localStorage.removeItem("cart");
  };

  return (
      <div className="container mx-auto px-4 py-10">
        <h2 className="text-xl font-bold mb-4">Cart Preview</h2>
        {cart.length === 0 ? (
          <p>Your cart is empty.</p>
        ) : (
          <div className="flex flex-wrap justify-center -mx-4">
            {cart.map((item, index) => (
              <div key={index} className="flex justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/4 px-4 mb-8">
                <Card isHoverable className="py-4">
                  <CardHeader className="pb-0 pt-2 px-4 flex-col items-start">
                    <h4 className="font-bold text-large line-clamp-1">{item.Name}</h4>
                  </CardHeader>
                  <CardBody className="overflow-visible py-2">
                    <p className="pt-4 line-clamp-4">{item.Description}</p>
                    <p className="pt-2 text-large">{item.Price} ₹</p>
                  </CardBody>
                  <CardFooter className="text-small">
                    <Button auto flat color="error" onClick={() => handleRemoveItem(item.Name)}>
                      Remove
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            ))}
          </div>
        )}
        {cart.length > 0 && (
          <div className="text-center mt-6">
            <Button onPress={handleEmptyCart} color="error">Empty Cart</Button>
          </div>
        )}
      </div>
  );
};

export default CartPreview;
