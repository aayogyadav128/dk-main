import { doc, getDoc } from "firebase/firestore";
import { db } from "./firebase"; // Make sure this path is correct based on your project structure


export const getPrivacy = async (language = 'en') => {
    try {
        const docRef = doc(db, 'pages', 'privacy');
        const docSnap = await getDoc(docRef);

        if (!docSnap.exists()) {
            throw new Error('No such document!');
        }

        const data = docSnap.data();
        // Fallback to English if the specified language is not available
        return data[language] || data['en'];
    } catch (error) {
        console.error('Error fetching privacy policy:', error);
        throw error;
    }
};




export const getShippingPolicy = async () => {
    try {
        const docRef = doc(db, 'pages', 'shipping');
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
            return docSnap.data().content; // Return the 'content' field
        } else {
            throw new Error('No such document!');
        }
    } catch (error) {
        console.error('Error fetching privacy policy:', error);
        throw error;
    }
};