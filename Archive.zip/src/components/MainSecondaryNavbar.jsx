import React from 'react';

const MainSecondaryNavbar = () => {
  return (
    <div className="bg-black overflow-hidden">
      <div className="py-1.5 whitespace-nowrap animate-marquee">
        <span
          className="text-2xl font-bold text-transparent font-bungee-outline"
          style={{
            WebkitTextStroke: '1px white',
            textShadow: `
              1px 0 0 white,
              -1px 0 0 white,
              0 1px 0 white,
              0 -1px 0 white,
              1px 1px white,
              -1px -1px 0 white,
              1px -1px 0 white,
              -1px 1px 0 white
            `,
          }}
        >
          this is my name
        </span>
      </div>
    </div>
  );
};

export default MainSecondaryNavbar;
