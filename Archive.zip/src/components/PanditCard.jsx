import React from "react";
import { Card, CardHeader, CardBody, Image, CardFooter, Button } from "@nextui-org/react";

export default function PanditCard({ panditData }) {
  return (
    <Card isBlurred isHoverable className="py-4" style={{width:'256px'}}>
      <CardHeader className="pb-0 pt-2 px-4 flex-col items-center">
        <Image
          alt="Pandit Image"
          className="object-cover rounded-full"
          src={panditData.image}
          width={100}
          height={100}
        />
        <h4 className="font-bold text-large mt-2">{panditData.name}</h4>
      </CardHeader>
      <CardBody className="overflow-visible py-2">
        <p className="pt-4 line-clamp-4 text-center">{panditData.description}</p>
      </CardBody>
      <CardFooter className="text-small justify-between">
        <p className="text-large">{panditData.chargePerHour} ₹/hour</p>
        <Button>Book Now</Button>
      </CardFooter>
    </Card>
  );
}
