'use client'
// components/AddReview.jsx
import React, { useState } from "react";
import { Card, Textarea, Button } from "@nextui-org/react";
import { FaStar } from "react-icons/fa";

const AddReview = ({ onSubmit }) => {
  const [comment, setComment] = useState("");
  const [rating, setRating] = useState(0);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ comment, rating });
    setComment("");
    setRating(0);
  };

  return (
    <Card className="p-5 mb-10 max-w-lg mx-auto">
      <h2 className="text-2xl font-bold mb-4">Add a Review</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <Textarea
            fullWidth
            label="Comment"
            placeholder="Write your review..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />
        </div>
        <div className="mb-4">
          <label className="block mb-2">Rating</label>
          <div className="flex">
            {[...Array(5)].map((_, index) => {
              const currentRating = index + 1;
              return (
                <FaStar
                  key={index}
                  size={24}
                  className={`cursor-pointer ${
                    currentRating <= rating ? "text-yellow-500" : "text-gray-400"
                  }`}
                  onClick={() => setRating(currentRating)}
                />
              );
            })}
          </div>
        </div>
        <Button type="submit" auto>Submit Review</Button>
      </form>
    </Card>
  );
};

export default AddReview;
