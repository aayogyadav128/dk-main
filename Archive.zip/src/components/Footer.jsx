'use client';
import { Link, Spacer, Divider, Image, Card } from '@nextui-org/react';

const Footer = () => {
  return (
    <div>
      <Card radius="none">
        <footer className="py-10">
          <div className="container mx-auto px-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10">
              <div className="flex flex-col items-center md:items-start mb-6 md:mb-0">
                <Image
                  src="/logo-black.png" // Ensure the leading slash for correctly pointing to the public folder
                  alt="Company Logo"
                  className="mb-4"
                  width={250}
                />
                <p className="text-center w-1/2 md:text-left">
                Bharat ke har kone se, aastha aur sanskaar ka digital saathi.
                </p>
              </div>
              <div className="flex flex-wrap justify-center md:justify-start">
                <div className="flex flex-col text-center md:text-left mr-6 mb-6">
                  <h4 className="font-bold mb-2">Book</h4>
                  <Link href="/pooja" className=" mb-1">Pooja</Link>
                  <Link href="/careers" className=" mb-1">Pandit</Link>
                  <Link href="/pricing" className=" mb-1">Stay</Link>
                  <Link href="/customers" className=" mb-1">Car</Link>
                  <Link href="/contact" className="">Blog</Link>
                </div>
                <div className="flex flex-col text-center md:text-left mr-6 mb-6">
                  <h4 className="font-bold mb-2">Resources</h4>
                  <Link href="/docs" className=" mb-1">Documentation</Link>
                  <Link href="/papers" className=" mb-1">Papers</Link>
                  <Link href="/faq" className="">FAQ</Link>
                </div>
                <div className="flex flex-col text-center md:text-left mr-6 mb-6">
                  <h4 className="font-bold mb-2">Legal & Compliance</h4>
                  <Link href="/terms" className=" mb-1">Terms of Service</Link>
                  <Link href="/privacy" className=" mb-1">Privacy Policy</Link>
                  <Link href="/cookies" className=" mb-1">Shipping Policy</Link>
                  <Link href="/data-processing" className="">Cancellation Policy</Link>
                </div>
              </div>
            </div>
            <Divider />
            <div className="flex flex-col md:flex-row px-10 justify-between items-center mt-10">
              <p>&copy; {new Date().getFullYear()} DivyaKumbh.in | All rights reserved.</p>
              <div className="flex space-x-4 mt-4 md:mt-0">
                <Link href="https://twitter.com" className="">Twitter</Link>
                <Link href="https://facebook.com" className="">Facebook</Link>
                <Link href="https://instagram.com" className="">Instagram</Link>
              </div>
            </div>
          </div>
        </footer>
      </Card>
    </div>
  );
}

export default Footer;