'use client'
import { Navbar, NavbarBrand, NavbarItem, NavbarContent, Link, Button, NavbarMenuItem, NavbarMenuToggle, NavbarMenu } from '@nextui-org/react';
import React, {useEffect } from 'react';
import { setCookie ,parseCookies} from 'nookies'; // To store JWT in cookies
import { useRouter } from 'next/navigation';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);
  const router = useRouter();

  const menuItems = [
    "Pooja", "Pooja", "Pandit", "Stay", "Car"
  ];
  useEffect(() => {
    // Check if JWT is already present in cookies
    const cookies = parseCookies();
    const jwt = cookies.jwt;

    // If JWT exists, redirect to dashboard
    if (!jwt) {
        router.push('/login');
    }else{
      setIsLoggedIn(true)
    }
}, [router]);
  return (
    <div>
      <Navbar
        style={{ height: 100, padding: 10 }}
        isBordered
        isMenuOpen={isMenuOpen}
        onMenuOpenChange={setIsMenuOpen}
      >
        <NavbarContent className="sm:hidden" justify="start">
          <NavbarMenuToggle aria-label={isMenuOpen ? "Close menu" : "Open menu"} />
        </NavbarContent>
        <NavbarBrand>
          <img width={200} src="/logo-black.png" alt="Logo" />
        </NavbarBrand>
        <NavbarContent className="hidden sm:flex gap-4" justify="center">
          <NavbarItem>
            <Link color="foreground" href="#">
              Book
            </Link>
          </NavbarItem>
          <NavbarItem isActive>
            <Link href="#" aria-current="page">
              Shop
            </Link>
          </NavbarItem>
          <NavbarItem>
            <Link color="foreground" href="#">
              Travel
            </Link>
          </NavbarItem>
        </NavbarContent>
        {!isLoggedIn&&<NavbarContent justify="end">
          <NavbarItem className="hidden lg:flex">
            <Link href="/login">Login</Link>
          </NavbarItem>
          <NavbarItem>
            <Button as={Link} color="primary" href="/signup" variant="flat">
              Sign Up
            </Button>
          </NavbarItem>
        </NavbarContent>}

        <NavbarMenu>
          {menuItems.map((item, index) => (
            <NavbarMenuItem key={`${item}-${index}`}>
              <Link
                className="w-full"
                color={
                  index === 2 ? "warning" : index === menuItems.length - 1 ? "danger" : "foreground"
                }
                href="#"
                size="lg"
              >
                {item}
              </Link>
            </NavbarMenuItem>
          ))}
        </NavbarMenu>
      </Navbar>
    </div>
  )
}

export default Header;