'use client'
// components/ProductPage.jsx
import React, { useEffect, useState } from "react";
import { Card, Button, Image, Grid } from "@nextui-org/react";
import ReviewCard from "./ReviewCard";
import { setCookie ,parseCookies} from 'nookies'; // To store JWT in cookies
import { useRouter } from 'next/navigation';

const ProductPage = ({ title, price, description, images, reviews, variations,id }) => {
  const [selectedImage, setSelectedImage] = useState(images[0]);
  const [login_state,setLoginState]=useState(false)
  const router=useRouter();
  useEffect(() => {
    // Check if JWT is already present in cookies
    const cookies = parseCookies();
    const jwt = cookies.jwt;

    // If JWT exists, redirect to dashboard
    if (!jwt) {
        router.push('/login');
    }else{
      setLoginState(true)
    }
}, [router]);


const handleSignIn = async (id) => {
  try {
    const cookies = parseCookies();
    const user_id=cookies.user_id;
      const response = await fetch('https://admin.divyakumbh.in/api/carts', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
              'Accept': '*/*',
          },
          body: JSON.stringify({
            "data": {
              "type": "pooja",
              "users_permissions_user": user_id,
              "pooja": id
            }
          }),
      });
      console.log(response)
      const result = await response.json();

      if (response.ok) {
        alert("Product Addded To Cart")
      } else {
        alert("Error While Adding To Cart")
      }
  } catch (err) {
      console.error('Error during login:', err);
  }
};

  return (
    <div>
      <Card className="p-5 mx-auto my-10 max-w-5xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="flex flex-col items-center">
            <Image src={selectedImage} alt={title} className="w-full h-auto rounded-lg" />
            <div className="flex overflow-x-auto mt-4 space-x-2 scrollbar-hide">
              {images.map((img, index) => (
                <img
                  key={index}
                  src={img}
                  alt={`${title} ${index + 1}`}
                  className={`w-16 h-16 object-cover rounded-lg cursor-pointer ${selectedImage === img ? "border-2 border-blue-500" : ""}`}
                  onClick={() => setSelectedImage(img)}
                />
              ))}
            </div>
          </div>
          <div className="flex flex-col justify-between h-full">
            <div>
              <h1 className="text-3xl font-bold">{title}</h1>
              <h3 className="text-xl text-gray-600">{price} ₹</h3>
              <div className="mt-4">
                <h4 className="text-lg font-semibold">Variations:</h4>
                <div className="flex flex-wrap mt-2 space-x-2">
                  {variations.map((variation, index) => (
                    <Button key={index} auto flat>{variation}</Button>
                  ))}
                </div>
              </div>
              {login_state&&<div className="flex space-x-4 mt-6">
                <Button onClick={()=>handleSignIn(id)}>Add to Cart</Button>
                <Button color="primary" shadow>Buy Now</Button>
              </div>}
            </div>
            <div className="mt-6">
              <h4 className="text-lg font-semibold">Description:</h4>
              <p>{description}</p>
            </div>
          </div>
        </div>
      </Card>
      <div className="reviews-section w-3/5 mx-auto mb-10">
        <h2 className="text-2xl font-bold mb-4">Customer Reviews</h2>
        {reviews.map((review, index) => (
          <ReviewCard key={index} review={review} />
        ))}
      </div>
    </div>
  );
};

export default ProductPage;
