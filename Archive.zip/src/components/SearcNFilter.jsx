// components/SearcNFilter.jsx
import React from 'react';
import { Button, Divider, Input } from '@nextui-org/react';
import { SearchIcon } from './SearchIcon';
import { FaFilter } from "react-icons/fa";

const SearcNFilter = () => {
  return (
    <div>
      <Divider />
      <div className='flex justify-between items-center px-4 py-2'>
        <Input
          classNames={{
            base: "w-3/5 lg:w-1/5  h-10",
            mainWrapper: "h-full",
            input: "text-small",
            inputWrapper: "h-full font-normal text-default-500 bg-default-400/20 dark:bg-default-500/20",
          }}
          placeholder="Type to search..."
          size="sm"
          startContent={<SearchIcon size={18} />}
          type="search"
        />
        <Button className="flex items-center">
          <FaFilter className="mr-2" />
          Filter
        </Button>
      </div>
    </div>
  );
};

export default SearcNFilter;
