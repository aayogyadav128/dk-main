import React from 'react';

const Loading = () => {
    return (
        <div className="flex items-center justify-center m-24">
            <div className="text-center">
                <img src="/animation1.gif" width='100' alt="Loading Animation" className="mx-auto" />
                <p className="mt-4">Loading...</p>
            </div>
        </div>
    );
};

export default Loading;