"use client";

import React, { useState, useEffect } from "react";
import { Button } from "@nextui-org/react";
import PoojaCard from "./PoojaCard";

const PoojaList = () => {
  const [poojaData, setPoojaData] = useState([]); // State to store pooja data
  const [visibleCount, setVisibleCount] = useState(4);
  const [loading, setLoading] = useState(true); // Loading state
  const [cart, setCart] = useState([]); // Cart state

  // Fetch pooja data from API
  useEffect(() => {
    const fetchPoojaData = async () => {
      try {
        const response = await fetch("https://admin.divyakumbh.in/api/poojas");
        const result = await response.json();
        setPoojaData(result.data); // Store fetched data
        setLoading(false);
      } catch (error) {
        console.error("Error fetching pooja data:", error);
        setLoading(false);
      }
    };

    fetchPoojaData();
  }, []);

  // Load cart from localStorage when the component mounts
  useEffect(() => {
    const savedCart = JSON.parse(localStorage.getItem("cart")) || [];
    setCart(savedCart);
  }, []);

  // Save cart to localStorage whenever it updates
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  // Add item to the cart
  const handleParticipate = (item) => {
    // Add item to cart if it's not already present
    setCart((prevCart) => {
      const isAlreadyInCart = prevCart.some((cartItem) => cartItem.Name === item.Name);
      if (!isAlreadyInCart) {
        return [...prevCart, item];
      } else {
        alert("This item is already in your cart.");
        return prevCart;
      }
    });
  };

  // Load more items functionality
  const loadMore = () => {
    setVisibleCount((prevCount) => prevCount + 4);
  };

  // Show loading spinner or loading message
  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-10">
      <div className="flex flex-wrap justify-center -mx-4">
        {poojaData.slice(0, visibleCount).map((pooja, index) => (
          <div key={index} className="flex justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/4 px-4 mb-8">
            <PoojaCard
              Data={{
                Name: pooja.attributes.title_english,
                Description: pooja.attributes.description_english,
                Image: "https://nextui.org/images/hero-card-complete.jpeg", // Replace this with actual image if available
                Organiser: "Admin",
                Price: pooja.attributes.plans,
                Date: pooja.attributes.date || "2024-09-10", // Use default date or API value
                Location: pooja.attributes.location || "Unknown",
              }}
              handleParticipate={handleParticipate}
            />
          </div>
        ))}
      </div>
      {visibleCount < poojaData.length && (
        <div className="text-center mt-6">
          <Button onPress={loadMore}>Load More</Button>
        </div>
      )}
      {/* Optional: Cart Summary */}
      <div className="mt-10">
        <h3>Cart Items:</h3>
        {cart.length === 0 ? (
          <p>No items in the cart.</p>
        ) : (
          <ul>
            {cart.map((item, index) => (
              <li key={index}>{item.Name} - {item.Price} ₹</li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default PoojaList;
