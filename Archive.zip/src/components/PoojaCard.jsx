import React from "react";
import { Card, CardHeader, CardBody, Image, CardFooter, Button } from "@nextui-org/react";
import { MdLocationOn } from "react-icons/md";
import { FaRegCalendarAlt } from "react-icons/fa";

export default function PoojaCard({ Data, handleParticipate }) {
  return (
    <Card isBlurred isHoverable className="py-4">
      <CardHeader className="pb-0 pt-2 px-4 flex-col items-start">
        <p className="text-tiny uppercase">{Data.Organiser}</p>
        <h4 className="font-bold text-large line-clamp-1">{Data.Name}</h4>
      </CardHeader>
      <CardBody className="overflow-visible py-2">
        <Image
          alt="Card background"
          className="object-cover w-full rounded-xl"
          src={Data.Image}
        />
        <p className="pt-4 line-clamp-4">{Data.Description}</p>
        <div className="pt-2">
          <div className="flex items-center mt-2">
            <MdLocationOn className="text-xl mr-1" />
            <span>{Data.Location}</span>
          </div>
          <div className="flex items-center mt-1">
            <FaRegCalendarAlt className="text-xl mr-1" />
            <span>{Data.Date}</span>
          </div>
        </div>
      </CardBody>
      <CardFooter className="text-small justify-between">
        <p className="text-large">{Data.Price} ₹</p>
        <Button style={{ background: 'red' }} onClick={() => handleParticipate(Data)}>
          Participate
        </Button>
      </CardFooter>
    </Card>
  );
}
