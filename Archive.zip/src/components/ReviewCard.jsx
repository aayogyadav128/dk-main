// components/ReviewCard.jsx
import React from "react";
import { Card, Avatar } from "@nextui-org/react";

const ReviewCard = ({ review }) => {
  const { userImage, userName, comment, rating } = review;

  return (
    <Card className="p-4 mb-4">
      <div className="flex items-center mb-4">
        <Avatar src={userImage} alt={userName} size="lg" className="mr-4" />
        <div>
          <h3 className="text-xl font-bold">{userName}</h3>
          <p className="text-gray-500">Rating: {rating} / 5</p>
        </div>
      </div>
      <p>{comment}</p>
    </Card>
  );
};

export default ReviewCard;
