// components/SecondaryNavbar.jsx
import React from 'react';
import { Card } from '@nextui-org/react';
import { FaHotel, FaBed, FaPagelines } from 'react-icons/fa';

const SecondaryNavbar = () => {
  const options = [
    { name: 'Hotel', icon: <FaHotel size={24} /> },
    { name: 'HomeStay', icon: <FaBed size={24} /> },
    { name: 'DharamShala', icon: <FaPagelines size={24} /> },
  ];

  return (
    <Card isBlurred className="p-4" radius='none'>
      <div className="flex justify-around items-center">
        {options.map((option, index) => (
          <div key={index} className="flex flex-col items-center text-center">
            <div className="text-white">{option.icon}</div>
            <p className="text-base mt-1">{option.name}</p>
          </div>
        ))}
      </div>
    </Card>
  );
};

export default SecondaryNavbar;
