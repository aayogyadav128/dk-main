// components/PoojaCardGrid.jsx
import React from 'react';
import PoojaCard from '../PoojaCard';
import poojaData from '@/poojaData';

const PoojaCardGrid = () => {
  // Sort the pooja data by price in descending order and take the top 4
  const topPoojas = poojaData
    .sort((a, b) => b.Price - a.Price)
    .slice(0, 4);

  return (
    <div className="flex flex-col justify-center items-center m-4">
      <div className="w-full max-w-5xl px-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Explore Poojas</h2>
          <a href="/poojas" className="text-blue-500 hover:text-blue-700">View All</a>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {topPoojas.map((pooja) => (
            <PoojaCard 
              key={pooja.id} 
              Data={pooja} 
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default PoojaCardGrid;
