import React from 'react';
import OfferCard from '../OfferCard';

const OffersSection = () => {
  const offerData = [
    {
      id: 1,
      title: "Special Diwali Offer",
      description: "Celebrate Diwali with special discounts on all spiritual services and products. Hurry, limited time offer!",
      image: "https://nextui.org/images/hero-card.jpeg"
    },
    {
      id: 2,
      title: "Navratri Festival Offer",
      description: "Get up to 50% off on Navratri poojas and rituals. Join us to celebrate the divine nine nights with special offers.",
      image: "https://nextui.org/images/hero-card.jpeg"
    }
  ];

  return (
    <div className="flex flex-col items-center">
      <h2 className="text-2xl font-bold mb-6">Offers</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl w-full px-4">
        {offerData.map((offer) => (
          <OfferCard
            key={offer.id}
            offer={offer}
          />
        ))}
      </div>
    </div>
  );
};

export default OffersSection;
