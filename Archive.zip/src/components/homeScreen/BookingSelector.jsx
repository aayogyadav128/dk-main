// components/BookingOptionsCard.jsx
import React from 'react';
import { Card } from '@nextui-org/react';

const BookingOptionsCard = ({ options }) => {
  return (
    <Card className="p-5 w-11/12 mt-10 mb-10 max-w-4xl mx-auto shadow-lg">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-l font-bold">What do you want to book?</h2>
        <a href="#" className="text-blue-500 hover:text-blue-700">View all &gt;&gt;&gt;</a>
      </div>
      <div className="flex overflow-x-auto space-x-6 scrollbar-hide">
        {options.map((option, index) => (
          <a 
            key={index} 
            href={option.link} 
            className="flex flex-col items-center min-w-max"
            target="_blank" 
            rel="noopener noreferrer"
          >
            <div className="w-22 h-22 bg-gray-200 rounded-full flex items-center justify-center mb-2">
              <img src={option.image} alt={option.name} className="w-20 h-20 object-cover rounded-full" />
            </div>
            <p className="text-center font-large">{option.name}</p>
          </a>
        ))}
      </div>
    </Card>
  );
};

export default BookingOptionsCard;
