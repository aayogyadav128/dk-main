'use client'
// components/ImageSlider.jsx
import React, { useState } from 'react';
import { Card, Button } from '@nextui-org/react';
import { FaArrowLeft, FaArrowRight } from 'react-icons/fa';

const ImageSlider = ({ images }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  return (
    <Card className="relative w-11/12 mx-auto mt-4  h-64 md:h-96 bg-black">
      <div className="absolute inset-0 flex items-center justify-between px-4">
        <Button auto onClick={prevSlide} icon={<FaArrowLeft />} light />
        <Button auto onClick={nextSlide} icon={<FaArrowRight />} light />
      </div>
      <div className="w-full h-full overflow-hidden">
        <a href={images[currentIndex].link} target="_blank" rel="noopener noreferrer">
          <img
            src={images[currentIndex].src}
            alt={`Slide ${currentIndex}`}
            className="object-cover w-full h-full"
          />
        </a>
      </div>
      <div className="absolute bottom-4 w-full flex justify-center space-x-2">
        {images.map((_, index) => (
          <div
            key={index}
            className={`h-2 w-2 rounded-full ${
              index === currentIndex ? 'bg-white' : 'bg-gray-400'
            }`}
          ></div>
        ))}
      </div>
    </Card>
  );
};

export default ImageSlider;
