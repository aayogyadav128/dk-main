const poojaData = [
  {
    id: 1,
    Name: "Saavan Pooja",
    Description: "Experience the divine blessings of Lord Shiva during the holy month of Saavan. Join us for an immersive spiritual journey.",
    Image: "https://nextui.org/images/hero-card-complete.jpeg",
    Organiser: "Admin",
    Price: 700,
    Date: "2023-07-22",
    Location: "Prayagraj"
  },
  {
    id: 2,
    Name: "Diwali Pooja",
    Description: "Celebrate the festival of lights with our Diwali Pooja, invoking the blessings of Goddess Lakshmi for prosperity and happiness.",
    Image: "https://nextui.org/images/hero-card-complete.jpeg",
    Organiser: "Admin",
    Price: 800,
    Date: "2023-11-04",
    Location: "Banaras"
  },
  {
    id: 3,
    Name: "Navratri Pooja",
    Description: "Join us for Navratri Pooja and worship the nine forms of Goddess Durga. Experience devotion and spiritual growth during these nine sacred nights.",
    Image: "https://nextui.org/images/hero-card-complete.jpeg",
    Organiser: "Admin",
    Price: 750,
    Date: "2023-10-15",
    Location: "Kolkata"
  },
  {
    id: 4,
    Name: "Ganesh Chaturthi Pooja",
    Description: "Invoke the blessings of Lord Ganesha, the remover of obstacles, during Ganesh Chaturthi Pooja. Participate in rituals and celebrations.",
    Image: "https://nextui.org/images/hero-card-complete.jpeg",
    Organiser: "Admin",
    Price: 650,
    Date: "2023-09-19",
    Location: "Mumbai"
  },
  {
    id: 5,
    Name: "Janmashtami Pooja",
    Description: "Celebrate the birth of Lord Krishna with Janmashtami Pooja. Join us for devotional songs, dances, and rituals in honor of Krishna.",
    Image: "https://nextui.org/images/hero-card-complete.jpeg",
    Organiser: "Admin",
    Price: 900,
    Date: "2023-08-28",
    Location: "Mathura"
  },
  {
    id: 6,
    Name: "Mahashivratri Pooja",
    Description: "Participate in Mahashivratri Pooja, dedicated to Lord Shiva. Experience a night of fasting, prayers, and meditations for spiritual awakening.",
    Image: "https://nextui.org/images/hero-card-complete.jpeg",
    Organiser: "Admin",
    Price: 850,
    Date: "2023-03-11",
    Location: "Ujjain"
  },
  {
    id: 7,
    Name: "Holika Dahan Pooja",
    Description: "Join us for Holika Dahan Pooja and celebrate the victory of good over evil. Witness the ceremonial bonfire and participate in traditional rituals.",
    Image: "https://nextui.org/images/hero-card-complete.jpeg",
    Organiser: "Admin",
    Price: 600,
    Date: "2023-03-06",
    Location: "Varanasi"
  },
  {
    id: 8,
    Name: "Ram Navami Pooja",
    Description: "Celebrate the birth of Lord Rama with Ram Navami Pooja. Join us for prayers, hymns, and the reading of Ramayana to honor Lord Rama.",
    Image: "https://nextui.org/images/hero-card-complete.jpeg",
    Organiser: "Admin",
    Price: 700,
    Date: "2023-04-10",
    Location: "Ayodhya"
  },
  {
    id: 9,
    Name: "Krishna Janmashtami Pooja",
    Description: "Join us for Krishna Janmashtami Pooja to celebrate the divine birth of Lord Krishna. Experience devotional songs and Dahi Handi festivities.",
    Image: "https://nextui.org/images/hero-card-complete.jpeg",
    Organiser: "Admin",
    Price: 950,
    Date: "2023-08-28",
    Location: "Dwarka"
  },
  {
    id: 10,
    Name: "Durga Pooja",
    Description: "Participate in Durga Pooja and worship the powerful Goddess Durga. Enjoy cultural programs, rituals, and festivities during this grand celebration.",
    Image: "https://nextui.org/images/hero-card-complete.jpeg",
    Organiser: "Admin",
    Price: 800,
    Date: "2023-10-04",
    Location: "Kolkata"
  },
  {
    id: 11,
    Name: "Lakshmi Pooja",
    Description: "Join us for Lakshmi Pooja to seek the blessings of the Goddess of wealth and prosperity. Engage in traditional rituals and prayers for abundance.",
    Image: "https://nextui.org/images/hero-card-complete.jpeg",
    Organiser: "Admin",
    Price: 850,
    Date: "2023-11-01",
    Location: "Chennai"
  },
  {
    id: 12,
    Name: "Saraswati Pooja",
    Description: "Celebrate Saraswati Pooja to honor the Goddess of knowledge and wisdom. Participate in rituals, and seek blessings for educational and artistic pursuits.",
    Image: "https://nextui.org/images/hero-card-complete.jpeg",
    Organiser: "Admin",
    Price: 750,
    Date: "2023-02-05",
    Location: "Bengaluru"
  }
];

export default poojaData; 